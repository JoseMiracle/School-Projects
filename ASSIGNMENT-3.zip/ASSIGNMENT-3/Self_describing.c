#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//The function is to check if number is self describing or not. 
int checkNumber(char casted_number[]){
    int length_of_number = strlen(casted_number);
    int value_at_differ_index[length_of_number]; //This is used in storing the values of the different index in  casted_number.
    int count_of_differ_index_in_the_number[length_of_number];
    int counted_value = 0;
    
    for(int i = 0; i < length_of_number ; i++ ){
        value_at_differ_index[i] = casted_number[i] - '0';
    }
    
     // This stores the number of each index within the range of length_of_number in casted number.
    
    for(int i = 0; i < length_of_number; i++) {
        counted_value = 0;
        for(int j = 0; j <= length_of_number; j++){
            int casted_value = casted_number[j] - '0';   
            if(i == casted_value){
                counted_value++;
            }
        }
    
       count_of_differ_index_in_the_number[i] = counted_value ;
    }
    
    int end_point = 0; //This is too check the the loop stops.
    for(int j = 0; j < length_of_number ; j++){
        if(value_at_differ_index[j] == count_of_differ_index_in_the_number[j]){
            end_point++;
        }
        else{
            break;
        }
    }
    
    if(end_point == length_of_number){
       return 1;
    }
    else{
        return 0;
    }

}

int main( ){
    int n = 0;
   
    long long int numbers[1000]; 
    FILE *file;
	
    file =  fopen("self.in", "r");
    
    if(file == NULL){
		printf("FIle DOESN'T EXIST");
	}

    else{
        while(fscanf(file, "%llu", &numbers[n]) != EOF){
            n++;
        }
        fclose(file);
    }
    
    //This is to get the total number of cases
    int total_number_to_be_checked = numbers[0]; 

    for(int i = 1 ; i <= total_number_to_be_checked ; i++ ){
        char casted_number[12];
        long long int digit = numbers[i];

        sprintf(casted_number, "%llu", digit);// This is used for casting the digit to string
        
        int value = checkNumber(casted_number);

        if (value == 1){
            printf("\n%llu is a self-describing number.\n\n", digit);
        }

        else if(value == 0){
            printf("\n%llu isn't a self-describing number.\n\n", digit);
        }

    }
}

